package com.example.encodemessagesapp;

import android.widget.ArrayAdapter;

public class ContactsChatsTitlesAdapter extends ArrayAdapter {
}

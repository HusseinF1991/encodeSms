package com.example.encodemessagesapp;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.SmsMessage;
import android.util.Log;

public class MySmsReceiver extends BroadcastReceiver {

    private static final int requestCode_SmsReceived = 314;

    private static final String TAG = MySmsReceiver.class.getSimpleName();
    public static final String pdu_type = "pdus";

    private static String SmsPrefix = "uruk";

    private String myPhoneNumber;
    private int simId;
    private Context myContext;

    @Override
    public void onReceive(Context context, Intent intent) {

        myContext = context;

        SharedPreferences sharedPref = context.getSharedPreferences("EncodeSmsSharedPrefereces", Context.MODE_PRIVATE);
        myPhoneNumber = sharedPref.getString("EncodeSmsPhone_SP", "notRegistered");
        simId = sharedPref.getInt("EncodeSmsSimId_SP", 0);

        Log.d(TAG , "checkMsgReceived true");

        // Get the SMS message.
        Bundle bundle = intent.getExtras();
        SmsMessage[] msgs;
        String strMessage_Sender = "";
        String strMessage_Body = "";
        String format = bundle.getString("format");


        // Retrieve the SMS message received.
        Object[] pdus = (Object[]) bundle.get(pdu_type);

        if (pdus != null) {

            // Fill the msgs array.
            msgs = new SmsMessage[pdus.length];
            for (int i = 0; i < msgs.length; i++) {
                // Check Android version and use appropriate createFromPdu.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    // If Android version M or newer:
                    msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i], format);
                } else {
                    // If Android version L or older:
                    msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                }

                // Build the message to show.
                strMessage_Sender = msgs[i].getOriginatingAddress();
                strMessage_Body =  msgs[i].getMessageBody() ;
            }
            // Log and display the SMS message.
            Log.d(TAG, strMessage_Sender +" , " + strMessage_Body);

            //trim the +964 prefix of the sender number
            if(!strMessage_Sender.startsWith("07")){

                strMessage_Sender = strMessage_Sender.substring(4 , strMessage_Sender.length());
                strMessage_Sender = "0" + strMessage_Sender;
            }

            Log.d(TAG, strMessage_Sender +" , " + strMessage_Body);

            if(strMessage_Body.startsWith(SmsPrefix)){

                //check if the sender is allowed to request location from this user(have connection) from sqlite DB
                MySqliteDB mySqliteDB = new MySqliteDB(context);

                String decryptedSms = AES.decrypt(strMessage_Body.substring(4 , strMessage_Body.length()) , strMessage_Sender+myPhoneNumber);

                if(decryptedSms.endsWith("true")){
                    String senderNumber = strMessage_Sender;
                    String senderName = null;

                    //check if the number is saved in contacts
                    String DISPLAY_NAME = ContactsContract.Contacts.DISPLAY_NAME;
                    Uri PhoneCONTENT_URI = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
                    String NUMBER = ContactsContract.CommonDataKinds.Phone.NUMBER;

                    ContentResolver contentResolver = myContext.getContentResolver();

                    // Query and loop for every phone number of the contact
                    Cursor phoneCursor = contentResolver.query(PhoneCONTENT_URI, null, null, null, null);

                    while (phoneCursor.moveToNext()) {
                        if
                        (
                                senderNumber.equals(phoneCursor.getString(phoneCursor.getColumnIndex(NUMBER))) ||
                                ("00964"+senderNumber).equals(phoneCursor.getString(phoneCursor.getColumnIndex(NUMBER))) ||
                                ("+964"+senderNumber).equals(phoneCursor.getString(phoneCursor.getColumnIndex(NUMBER)))
                        ) {
                            senderName = phoneCursor.getString(phoneCursor.getColumnIndex(DISPLAY_NAME));
                            break;
                        }
                    }
                    phoneCursor.close();


                    //save the received sms in the sqlite db
                    String trimmedDecryptedSms = decryptedSms.substring(0  ,strMessage_Body.length() - 4 );
                    mySqliteDB.SaveReceivedSms(senderNumber , trimmedDecryptedSms  , "received" , 0);

                    //make notification for the new received sms
                    //make broadcast received by the activity that displays the sms
                    if(senderName == null)  notification_broadcast_SmsReceived(senderNumber);
                    else  notification_broadcast_SmsReceived(senderName);
                }
            }
        }
    }






    //make notification and broadcast for the received sms
    private void notification_broadcast_SmsReceived(String sender) {

        //send  broadcast intent to notify mainActivity that new sms received
        Intent intent1 = new Intent("newSmsReceived_MainActivity");
        LocalBroadcastManager.getInstance(myContext).sendBroadcast(intent1);

        //send broadcast to the sender activity to show the sms
        //
        //

        //intent for notification pending intent
        Intent intent2 = new Intent(myContext , MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity
                (myContext , requestCode_SmsReceived , intent2 , PendingIntent.FLAG_CANCEL_CURRENT);

        String notificationTitle = "رسالة جديدة";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(myContext, "channel1")
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setContentTitle(notificationTitle)
                .setSmallIcon(R.mipmap.ic_launcher_round)
                .setContentText(sender)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(myContext);
        // notificationId is a unique int for each notification that you must define

        int notificationId = (int) System.currentTimeMillis();
        notificationManager.notify(notificationId, builder.build());
    }
}

package com.example.encodemessagesapp;

import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;

import java.util.Calendar;
import java.util.Date;


public class MySqliteDB extends SQLiteOpenHelper {


    private static final String sqliteDbName = "EncodeMessagesApp";

    public MySqliteDB(@Nullable Context context) {
        super(context, sqliteDbName , null, 1);


        Log.d("sqlite_db" ,"called");

        SQLiteDatabase mySqlite = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("sqlite_db" ,"Created");

        db.execSQL("CREATE TABLE IF NOT EXISTS `messages` (" +
                "Id INTEGER NOT NULL primary key AUTOINCREMENT , " +
                "phoneNumber varchar(25) NOT NULL, " +
                "message varchar(255) NOT NULL, " +
                "sent_received varchar(20) NOT NULL, " +
                "read INTEGER DEFAULT 0 NOT NULL, " +
                "date DateTime DEFAULT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        Log.d("sqlite_db" ,"Upgraded");
    }


    public boolean SaveReceivedSms(String senderNumber ,String sms , String sent_received , int readStatus){

        Log.d("sqlite_db" , "InsertToMessagesTbl_started");

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("phoneNumber" , senderNumber);
        contentValues.put("message" ,sms );
        contentValues.put("sent_received" , sent_received);
        contentValues.put("read" , readStatus);
        contentValues.put("date" , String.valueOf(Calendar.getInstance().getTime()));

        Long result = sqLiteDatabase.insert( "messages" , null , contentValues);

        Log.d("sqlite_db" , "InsertNewSms" + result);

        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }


    public boolean UpdateSmsReadStatus(String senderNumber){

        Log.d("sqlite_db" , "UpdateToMessagesTbl_started");

        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("read" , 1);

        int result = sqLiteDatabase.update("messages" , contentValues , "phoneNumber = ? " , new String[]{senderNumber});

        Log.d("sqlite_db" , "Update Read status " + result);

        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }

}
